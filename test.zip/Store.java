import java.util.Scanner; // Import the Scanner class

public class Store {

    public static void main(String[] args) {


        Scanner scanner = new Scanner(System.in); //Create a Scanner object

        int quantityOfProducts = 0;



        while (scanner.hasNextLine()) {
            String line = scanner.nextLine(); // Read input user;

            if (line == null || line.trim().isEmpty())
                break; // Se a linha lida for vazia eu paro o funcionamento do programa


            String[] parts = line.split(", ");
            switch (parts[0]){
                case "I":
                    if(parts[1].equals("Livro")) {
                        print(parts);
                    }else if (parts[2].equals("CD")){
                        print(parts);

                    }else{
                        print(parts);

                    }
                case "A":
                case "V":
                case "P":
                case "S":
                    break;
            }

        }



    }

    public static void print(String[] parts){
        for (String part : parts) System.out.println(part);
    }



}
