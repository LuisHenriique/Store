public class Products {
    protected String name;
    protected int spaceCode;
    protected String category;

    public Products(String name, int spaceCode){
    this.name = name;
    this.spaceCode = spaceCode;
    }


}
