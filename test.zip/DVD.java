public class DVD extends Products{
    private String nameFilm;
    private String director;
    private String language;
    private String filmGenre;
    private int year;
    private String nationality;

    public DVD(String name, int spaceCode, String nameFilm, String director, String language, String filmGenre, int year, String nationality) {
        super(name, spaceCode);
        this.nameFilm = nameFilm;
        this.director = director;
        this.language = language;
        this.filmGenre = filmGenre;
        this.year = year;
        this.nationality = nationality;
    }
}
