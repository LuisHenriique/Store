public class Book extends Products {

    private String nameBook;
    private String author;
    private String publisher;
    private int year;
    private int edition;
    private int pages;
    private String language;


    public Book(String name, int spaceCode, String nameBook, String author, String publisher, int year, int edition, int pages, String language) {
        super(name, spaceCode);
        this.nameBook = nameBook;
        this.author = author;
        this.publisher = publisher;
        this.year = year;
        this.edition = edition;
        this.pages = pages;
        this.language = language;


    }
}
