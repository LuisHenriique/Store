public class CD extends Products{
    private String titleAlbum;
    private String nameSinger;
    private int numbers_musics;
    private String recordCompany;
    private int year;


    public CD(String name, int spaceCode, int year, String recordCompany, int numbers_musics, String nameSinger, String titleAlbum) {
        super(name, spaceCode);
        this.year = year;
        this.recordCompany = recordCompany;
        this.numbers_musics = numbers_musics;
        this.nameSinger = nameSinger;
        this.titleAlbum = titleAlbum;
    }
}
